
import java.security.SecureRandom;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mateus
 */
public class Teste {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        SecureRandom gerador = new SecureRandom();
        
        Enquete e = new Enquete();
        int numeroLido;
      
        System.out.println("Informe a quantidade de entrevistados:");
        numeroLido = input.nextInt();
        int []quantidade = new int[numeroLido];
        
        System.out.println("Notas geradas: ");
        for(int i =0; i < numeroLido; i++){
            quantidade[i] = gerador.nextInt(10)+1;
        }
        
        System.out.println("Frequencia: ");
        e.frequencia(quantidade);
        System.out.println("Media: ");
        e.setQuantidade(numeroLido);
        e.media(quantidade);
        e.entrevistados();
    }
    
}

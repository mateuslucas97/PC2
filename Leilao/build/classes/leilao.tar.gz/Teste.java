/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author mateus
 */
import java.util.Scanner;
public class Teste {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.print("Informe a quantidade de lotes: ");
            int qtde_lotes = input.nextInt();
            Leilao leilao = new Leilao(qtde_lotes);
            //Adicionando os lotes
            Lote lote;
            for(int i = 0; i < qtde_lotes; i++){
                System.out.printf("Informe a descrição do %d° lote: ", i+1);
                String descricao = input.next();
                lote = new Lote(descricao);
                leilao.adicionaLote(lote);
            }
        
    }
    
}

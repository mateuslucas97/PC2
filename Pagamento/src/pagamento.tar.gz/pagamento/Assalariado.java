/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pagamento;

/**
 *
 * @author mateus
 */
public class Assalariado extends Empregado implements Pagavel {
    
    public Assalariado(String nome, String sobrenome, int numIdent){
        super();
    }
    
    @Override
    public double getValorAPagar(int dia, int hora){
        double total = 0;
        if(hora > 40){
            total = hora * ControlePagamento.HORA + ControlePagamento.SALARIO;
        }
        return total;
    }
    
}

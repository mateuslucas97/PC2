/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pagamento;

/**
 *
 * @author mateus
 */
public class Concessionaria extends Titulo {
    
    public Concessionaria(){
        super();
    }
    
    public double getValorAPagar(int dia){
        if(dia > this.dia){
           
        }
    return valor;
    }
}

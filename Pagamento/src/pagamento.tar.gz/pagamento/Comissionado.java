/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pagamento;

/**
 *
 * @author mateus
 */
public class Comissionado extends Empregado implements Pagavel {
    
    public Comissionado(String nome, String sobrenome, int numIdent){
        super();
    }

    @Override
    public double getValorAPagar(int dia, int hora) {
       double total;
       total = ControlePagamento.SALARIO * 0.6;
       
       return total;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pagamento;

/**
 *
 * @author mateus
 */
public class AssalariadoComissionado extends Terceirizado implements Pagavel {
    
    public AssalariadoComissionado(String nome, String sobrenome, int numIdent){
        super(nome, sobrenome, numIdent);
    }
    
    public double getValorAPagar(){
        double total;
        total = ControlePagamento.SALARIO + ControlePagamento.SALARIO * 0.6;
        return total;
    }
    
}

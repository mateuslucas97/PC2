/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pagamento;

/**
 *
 * @author mateus
 */
public class Titulo extends Conta {
    
    public Titulo(){
        super();
    }
    
    @Override
    public double getValorAPagar(int dia, int hora){
        if(dia > this.dia){
            valor = valor + 0.10 * valor; 
        }
        return valor;
    }
}
